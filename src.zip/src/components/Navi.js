import React from 'react';
import './Mys.css'

function Navi() {
    return (
        <div>
			<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Post Office MSI</a>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
			  <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
			  <li class="nav-item active dropdown">
				<a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tansactions</a>
				<div class="dropdown-menu" aria-labelledby="dropdown04">
					<a class="dropdown-item" href="register_t.html">Register Post</a>
					<a class="dropdown-item" href="moneyorder_t.html">Money Order</a>
				  <a class="dropdown-item" href="ftc_t.html">Fast track courier</a>
				</div>
			  </li>
	        </ul>
	      </div>
	    </div>
	  </nav>
		</div>
    );
    
}

export default Navi