import React from 'react';
import './Mys.css'

function Body(){
    return(
        <div>
										<h2>Good Postal Service</h2>
										<p>For the betterment of every home</p>
										<p><a href="npost.html" class="btn btn-primary">Normal Post</a></p>
										<p><a href="rpost.html" class="btn btn-primary">Registered  Post</a></p>
										<p><a href="ftc.html" class="btn btn-primary">Fast track courier</a></p>
										<p><a href="morder.html" class="btn btn-primary">Money Order</a></p>
									</div>
    );
}

export default Body;