import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Navi from './components/Navi';
import Upperline from './components/UpperLine';
import Body from './components/Body';
import Footer from './components/Footer'
class App extends Component{
  render(){
    return(
      <div className='App'>
        <Upperline/>
        <Navi/>
        <Body/>
        <Footer/>
      </div>
    );
  }
}

export default App;
